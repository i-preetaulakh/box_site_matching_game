download the zip file
