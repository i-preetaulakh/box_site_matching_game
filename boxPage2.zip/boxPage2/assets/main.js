function createGrid(rows, cols) {
    document.getElementById('home').style.display = 'none';
    document.getElementById('gamePage').style.display = 'block';

    const totalCards = rows * cols;
    const gameBoard = document.getElementById("gameBoard");
    gameBoard.innerHTML = "";
    gameBoard.style.gridTemplateColumns = `repeat(${cols}, 5em)`;
    gameBoard.style.gridTemplateRows = `repeat(${rows}, 6em)`;

    for (let i = 0; i < totalCards; i++) {
        const card = document.createElement("div");
        card.classList.add("card");
        gameBoard.appendChild(card);
    }
}

function goBack() {
    document.getElementById('home').style.display = 'flex';
    document.getElementById('gamePage').style.display = 'none';
}